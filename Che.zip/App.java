package Max.Che;

import Max.Che.AgregationAndComposition.*;
import Max.Che.Objects.*;

public class App {

    public static void main(String[] args) {

        SomeClass<A> someClass2 = new SomeClass<>(new A(4));
        SomeClass<B> someClass1 = new SomeClass<>(new B(4,4));
        SomeClass<C> someClass = new SomeClass<>(new C(4,4,6));
        SomeClass<String> someClass3 = new SomeClass<>("Vasya");

        func(someClass2);
        func(someClass1);
        func(someClass);
    }
    public static void func(SomeClass<? extends A> a){
        try {
            f((C)a.getObj());
//        System.out.println(obj.getClass().toString());
        }catch (Exception e){
            try{
                f((B)a.getObj());
            }catch (Exception e1){
                f(a.getObj());
            }
        }
    }
    private static void f(A a){

        System.out.println(a.getClass()+ "f(A a)" );
    }
    public static void f(B b){

        System.out.println(b.getClass()+"f(B b)");
    }
    public static void f(C c ){
        System.out.println(c.getClass()+"f(C c)");
    }


}
