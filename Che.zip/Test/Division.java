package Max.Che.Test;

public class Division implements IAction {
    @Override
    public Integer action(Integer a, Integer b) {
        return a/b;
    }

    @Override
    public Double action(Double a, Double b) {
        return a/b;
    }

    @Override
    public Long action(Long a, Long b) {
        return a/b;
    }

    @Override
    public Float action(Float a, Float b) {
        return a/b;
    }

    @Override
    public String action(String a, String b) {
        return null;
    }
}
