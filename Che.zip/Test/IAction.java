package Max.Che.Test;

public interface IAction {
    Integer action(Integer a, Integer b);
    Double action(Double a, Double b);
    Long action(Long a, Long b);
    Float action(Float a, Float b);
    String action(String a, String b);
}
