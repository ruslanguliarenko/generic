package Max.Che.Objects;

public class C extends B {
    private int c;

    public C(int b, int a, int c) {
        super(b, a);
        this.c = c;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }
}
