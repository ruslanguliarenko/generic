package Max.Che.Objects;

public class SomeClass<T> {
    T obj;

    private String asdfasfs;
    public SomeClass(T obj) {
        this.obj = obj;
    }

    public T getObj() {
        return obj;
    }

    public void setObj(T obj) {
        this.obj = obj;
    }
}
