package Max.Che.Objects;

import Max.Che.AgregationAndComposition.Auto;

import java.util.Objects;

public class A {
    private int a;

    public A(int a) {
        this.a = a;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    @Override
    public String toString() {
        return "A{" +
                "a=" + a +
                '}';
    }
}
