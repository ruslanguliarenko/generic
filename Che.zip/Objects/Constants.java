package Max.Che.Objects;

public class Constants {
    private static int id=0;

    public static int getId() {
        return ++id;
    }


}
