package Max.Che.Objects;

public class bla_bla {
    private A a;

    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }

    public bla_bla(A a) {
        this.a = a;
    }
}
