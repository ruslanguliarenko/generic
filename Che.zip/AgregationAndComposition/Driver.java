package Max.Che.AgregationAndComposition;

public class Driver {
    private String name;
    private Auto auto;
    private boolean isAutoSet;

    public Driver(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String sayWhuchAutoDoYouUse(){
        return null;
    }

    public Auto getAuto() {
        return auto;
    }

    public void setAuto(Auto auto) {
        System.out.println("setAuto()");
        this.auto = auto;
        this.auto.setDriver(this);
    }

    @Override
    public String toString() {
        return "Driver{" +
                "name='" + name + '\'' +
                '}';
    }
}
