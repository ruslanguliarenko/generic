package Max.Che.AgregationAndComposition;

public enum EngineType {
    disel,
    gasoline,
    gibryde;

}
