package Max.Che.AgregationAndComposition;

public class Auto {
    private String brand;
    private String serialNumber;

    private Engine engine;
    private Driver driver;

    public Auto(String brand, String serialNumber, String EngineSerialNumber, double volume, String type) {
        this.brand = brand;
        this.serialNumber = serialNumber;
        engine = new Engine(EngineSerialNumber,volume,type);
    }
    public Auto(String brand, String serialNumber) {
        this.brand = brand;
        this.serialNumber = serialNumber;
        engine = new Engine("sghfjhw2342dfgv",2.0,EngineType.disel.toString());
    }
    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        System.out.println("setDriver()");
        this.driver = driver;
        this.driver.setAuto(this);

    }

    public String getBrand() {
        return brand;
    }

    public String getSerialNumber() {
        return serialNumber;
    }
    public double getEngineVolume(){
        return engine.getVolume();
    }

    @Override
    public String toString() {
        return "Auto{" +
                "brand='" + brand + '\'' +
                ", serialNumber='" + serialNumber + '\'' +
                ", engine=" + engine.toString()+
                ", driver=" + ((driver ==null) ? "no one" : driver.toString()) +
                '}';
    }
}
class Engine {
    private String serialNumber;
    private double volume;
    private String type;

    Engine(String serialNumber, double volume, String type) {
        this.serialNumber = serialNumber;
        this.volume = volume;
        this.type = type;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public double getVolume() {
        return volume;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "Engine{" +
                "serialNumber='" + serialNumber + '\'' +
                ", volume=" + volume +
                ", type='" + type + '\'' +
                '}';
    }
}